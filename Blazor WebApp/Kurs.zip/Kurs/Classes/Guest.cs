﻿namespace Kurs.Classes
{
    public class Guest 
    {
    }
}
